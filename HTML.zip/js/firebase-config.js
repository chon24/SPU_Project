import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js";
import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore.js";

// ✅ ตั้งค่า Firebase
const firebaseConfig = {
    apiKey: "AIzaSyBeRhouLPjkAv1JLiHeugaYIOqFoP2gTMI",
    authDomain: "crane-lifting-plan.firebaseapp.com",
    projectId: "crane-lifting-plan",
    storageBucket: "crane-lifting-plan.appspot.com",
    messagingSenderId: "1081219322931",
    appId: "1:1081219322931:web:00f0160bbc7e178ddf3f46"
};

// ✅ Initialize Firebase และ Firestore
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

console.log("✅ Firebase Initialized:", app.name);

// ✅ ฟังก์ชันทดสอบ Firestore
async function testFirestore() {
    try {
        console.log("📡 กำลังดึงข้อมูลจาก Firestore...");
        const querySnapshot = await getDocs(collection(db, "Crane"));

        if (querySnapshot.empty) {
            console.warn("⚠️ ไม่มีข้อมูลใน Collection 'Crane'");
        } else {
            console.log("📌 Firestore Data:", querySnapshot.docs.map(doc => doc.data()));
        }
    } catch (error) {
        console.error("❌ Firestore Error:", error);
    }
}

// ✅ เรียกใช้งานทดสอบ
testFirestore();

export { db };
