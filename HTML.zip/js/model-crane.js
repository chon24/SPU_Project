import { db } from "./firebase-config.js";
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore.js";

document.addEventListener("DOMContentLoaded", async function () {
    console.log("🔥 กำลังโหลดข้อมูล Model Crane...");

    // ✅ ดึงค่า Model จาก URL
    const params = new URLSearchParams(window.location.search);
    let selectedModel = params.get("model");

    if (!selectedModel) {
        console.error("❌ ไม่พบ Model ใน URL!");
        return;
    }

    selectedModel = decodeURIComponent(selectedModel.trim());
    console.log("📌 Model ที่เลือกหลังแก้ไข:", selectedModel);

    // ✅ ดึง Element ที่ต้องใช้
    const modelTitle = document.getElementById("modelTitle");
    const craneImage = document.getElementById("craneImage");
    const modelName = document.getElementById("modelName");
    const liftingCapacity = document.getElementById("liftingCapacity");
    const hookHeight = document.getElementById("hookHeight");
    const boomMax = document.getElementById("boomMax");
    const boomMin = document.getElementById("boomMin");
    const boomSections = document.getElementById("boomSections");
    const raisingSpeed = document.getElementById("raisingSpeed");
    const weight = document.getElementById("weight");

    try {
        console.log("📡 กำลังดึงข้อมูลจาก Firestore สำหรับ Model:", selectedModel);
        const docRef = doc(db, "Crane", selectedModel);
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
            const data = docSnap.data();
            console.log("📌 ข้อมูลที่โหลดจาก Firebase:", data);

            // ✅ ตรวจสอบและอัปเดต UI
            modelTitle.textContent = data.model || "Unknown Model";
            craneImage.src = data.image_url && data.image_url.trim() !== "" 
                ? data.image_url 
                : "./images/default-image.png"; 

            modelName.textContent = data.model || "N/A";
            liftingCapacity.textContent = data.lifting_capacity || "N/A";
            hookHeight.textContent = data.hook_height || "N/A";
            boomMax.textContent = data.boom_length_max || "N/A";
            boomMin.textContent = data.boom_length_min || "N/A";
            boomSections.textContent = data.boom_sections || "N/A";
            raisingSpeed.textContent = data.raising_speed || "N/A";
            weight.textContent = data.weight || "N/A";
        } else {
            console.error("❌ ไม่พบข้อมูล Model Crane ใน Firestore!");
        }
    } catch (error) {
        console.error("❌ Error โหลด Model:", error);
    }

    document.getElementById("backButton").addEventListener("click", function () {
        window.history.back();
    });

    document.getElementById("nextButton").addEventListener("click", function () {
        alert("ฟังก์ชัน Next ยังไม่ถูกกำหนด!");
    });
});
 