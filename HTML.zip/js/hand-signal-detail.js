document.addEventListener("DOMContentLoaded", function () {
    console.log("🔍 กำลังโหลดข้อมูล...");

    const params = new URLSearchParams(window.location.search);
    const signalImage = document.getElementById("signalImage");
    const signalDescription = document.getElementById("signalDescription");
    const videoSource = document.getElementById("videoSource");
    const signalVideo = document.getElementById("signalVideo");

    const imgSrc = params.get("img");
    const desc = params.get("desc");
    const videoFile = params.get("video"); // ใช้ชื่อไฟล์แทน ID

    console.log("📌 ตรวจสอบค่าที่ดึงจาก URL:");
    console.log("📌 img:", imgSrc);
    console.log("📌 desc:", desc);
    console.log("📌 video:", videoFile);

    // ✅ รายการสัญญาณมือและวิดีโอที่ตรงกัน
    const signals = [
        { img: "signal1.png", desc: "เลื่อนรอกขึ้น", video: "video1.mp4" },
        { img: "signal2.png", desc: "เลื่อนรอกขึ้นช้าๆ", video: "video2.mp4" },
        { img: "signal3.png", desc: "เลื่อนรอกลงช้าๆ", video: "video3.mp4" },
        { img: "signal4.png", desc: "ยกบูม", video: "video4.mp4" },
        { img: "signal5.png", desc: "นอนบูม", video: "video5.mp4" },
        { img: "signal6.png", desc: "ยืดบูม", video: "video6.mp4" },
        { img: "signal7.png", desc: "หดบูม", video: "video7.mp4" },
        { img: "signal8.png", desc: "สั่งให้ชุดรอกไปทางซ้าย", video: "video8.mp4" },
        { img: "signal9.png", desc: "สั่งให้ชุดรอกไปทางขวา", video: "video9.mp4" },
        { img: "signal10.png", desc: "ขยับรอกช้าๆ", video: "video10.mp4" },
        { img: "signal11.png", desc: "ใช้รอกใหญ่", video: "video11.mp4" },
        { img: "signal12.png", desc: "หยุดยก", video: "video12.mp4" },
        { img: "signal13.png", desc: "ใช้รอกเล็ก", video: "video13.mp4" },
        { img: "signal14.png", desc: "หยุดฉุกเฉิน", video: "video14.mp4" },
        { img: "signal15.png", desc: "เลื่อนรอกลง", video: "video15.mp4" }
    ];

    // ✅ ค้นหาวิดีโอที่ตรงกับไอคอนที่กด
    let currentIndex = signals.findIndex(s => s.img === imgSrc);

    if (currentIndex === -1) {
        console.warn("⚠️ ไม่พบสัญญาณมือที่ตรงกับ imgSrc:", imgSrc);
        currentIndex = 0; // ถ้าไม่เจอ ใช้ตัวแรก
    }

    const selectedSignal = signals[currentIndex];

    // ✅ ตั้งค่ารูปภาพและคำอธิบาย
    signalImage.src = `../images/${selectedSignal.img}`;
    signalDescription.textContent = selectedSignal.desc;

    // ✅ ตั้งค่าวิดีโอให้ตรงกับไอคอนที่กด
    videoSource.src = `../sample-video.mp4/${selectedSignal.video}`;
    console.log("🎥 โหลดวิดีโอจากโฟลเดอร์:", videoSource.src);
    signalVideo.load();

    // ✅ เล่นอัตโนมัติ และวนซ้ำ
    signalVideo.muted = true;  // ปิดเสียงให้เล่นอัตโนมัติได้
    signalVideo.loop = true;
    signalVideo.autoplay = true;

    signalVideo.play().then(() => {
        console.log("✅ วิดีโอเริ่มเล่นอัตโนมัติจากไฟล์ในเครื่อง");
    }).catch(error => {
        console.error("❌ ไม่สามารถเล่นวิดีโอได้:", error);
    });

    // ✅ ฟังก์ชันเปลี่ยนวิดีโอเมื่อกด Next และ Back
    const nextButton = document.getElementById("nextButton");
    const backButton = document.getElementById("backButton");

    if (nextButton) {
        nextButton.addEventListener("click", function () {
            currentIndex = (currentIndex + 1) % signals.length;
            const nextSignal = signals[currentIndex];
            window.location.href = `hand-signal-detail.html?img=${nextSignal.img}&desc=${nextSignal.desc}&video=${nextSignal.video}`;
        });
    } else {
        console.error("❌ ไม่พบปุ่ม Next!");
    }

    if (backButton) {
        backButton.addEventListener("click", function () {
            currentIndex = (currentIndex - 1 + signals.length) % signals.length;
            const prevSignal = signals[currentIndex];
            window.location.href = `hand-signal-detail.html?img=${prevSignal.img}&desc=${prevSignal.desc}&video=${prevSignal.video}`;
        });
    } else {
        console.error("❌ ไม่พบปุ่ม Back!");
    }

    // ✅ ปุ่มย้อนกลับไปหน้า Hand Signal
    const backToMenu = document.getElementById("backToMenu");
    if (backToMenu) {
        backToMenu.addEventListener("click", function () {
            window.location.href = "hand-signal.html";
        });
    } else {
        console.error("❌ ไม่พบปุ่ม Back To Menu!");
    }
});
