// ✅ Import Firestore จาก Firebase
import { db } from "./firebase-config.js";
import { collection, getDocs } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore.js";

document.addEventListener("DOMContentLoaded", async function () {
    console.log("🔥 กำลังโหลดข้อมูล Lifting Plan...");

    const liftingPlanContainer = document.getElementById("liftingPlanContainer");

    try {
        const querySnapshot = await getDocs(collection(db, "Crane"));

        if (querySnapshot.empty) {
            liftingPlanContainer.innerHTML = `<p class="error-message">❌ ไม่มีข้อมูลเครนในฐานข้อมูล</p>`;
            return;
        }

        let content = `<div class="crane-grid">`;

        querySnapshot.forEach((doc) => {
            const craneData = doc.data();
            const modelName = encodeURIComponent(craneData.model.trim()); // ✅ ใช้ URL Encoding แทน
            const imageUrl = craneData.image_url && craneData.image_url.trim() !== "" 
                ? craneData.image_url 
                : "./images/no-image.png"; // ✅ เปลี่ยนรูปสำรอง

            console.log(`📌 เพิ่มไอคอนเครน: ${craneData.model} -> URL: ${imageUrl}`);

            content += `
                <div class="crane-item" onclick="navigateToModel('${modelName}')">
                    <img src="${imageUrl}" alt="${craneData.model}" class="crane-img">
                    <p class="crane-model">${craneData.model}</p>
                </div>
            `;
        });

        content += `</div>`;
        liftingPlanContainer.innerHTML = content;

    } catch (error) {
        console.error("❌ Firestore Error:", error);
        liftingPlanContainer.innerHTML = `<p class="error-message">❌ ไม่สามารถโหลดข้อมูลได้</p>`;
    }
});

// ✅ ฟังก์ชันเปลี่ยนหน้าไปยัง Model Crane
window.navigateToModel = function (model) {
    console.log("🔍 กำลังเปลี่ยนไปที่ Model:", model);
    window.location.href = `model-crane.html?model=${model}`;
};
