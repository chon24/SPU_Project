document.addEventListener("DOMContentLoaded", function () {
    const handSignalIcons = document.querySelectorAll(".hand-signal-box img");

    handSignalIcons.forEach(icon => {
        icon.addEventListener("click", function () {
            const imgSrc = this.getAttribute("src").split("/").pop();
            const desc = this.nextElementSibling.textContent;

            window.location.href = `hand-signal-detail.html?img=${imgSrc}&desc=${desc}&video=sample-video.mp4`;
        });
    });

    // ปุ่มย้อนกลับไปหน้า Welcome
    const backButton = document.getElementById("backButton");
    if (backButton) {
        backButton.addEventListener("click", function () {
            window.location.href = "welcome.html";
        });
    }
});
